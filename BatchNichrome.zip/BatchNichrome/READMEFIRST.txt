READ THIS CAREFULLY BEFORE EXECUTING THE BATCH FILE

NOTE: THIS IS A MALWARE CREATED BY BLAZENOTHERE FOR EDUCATIONAL PURPOSES ONLY


Hello there! Glad you opened this before executing the batch file. That file is malware.
This was created for educational purposes and NOT for destroying your PC. Only run the batch file if you are testing it in a safe environment, a VM. If you have no idea what a malware is or anything, DO NOT CLICK THE .BAT FILE.
What this virus does is delete your C:/ drive entirely. If you are using it in a safe environment like a VM, then run the batch file as administator for the .bat to function. No warnings are given before the .bat is run.

CREATOR NOT RESPONSIBLE FOR DATA LOSS

Made with EDUCATION by https://github.com/BlazeNotHere

BatchCobalt (BatchNichrome V2) coming soon.
Probably will be available by end of April 2024 at https://github.com/BlazeNotHere/BatchCobalt 
